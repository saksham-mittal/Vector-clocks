The folder ProgAssn1-CS16BTECH11032 contains two .cpp files :
VC-CS16BTECH11032.cpp
SK-CS16BTECH11032.cpp

To run these files on Ubuntu, run the following command:
1. For VC-CS16BTECH11032.cpp
g++ -std=c++11 -pthread VC-CS16BTECH11032.cpp -o VC-CS16BTECH11032

2. For SK-CS16BTECH11032.cpp
g++ -std=c++11 -pthread SK-CS16BTECH11032.cpp -o SK-CS16BTECH11032

To excecute:
1. For VC-CS16BTECH11032.cpp
./VC-CS16BTECH11032

2. For SK-CS16BTECH11032.cpp
./SK-CS16BTECH11032

The log files will be generated in Log-VC.txt (for VC-CS16BTECH11032.cpp) and Log-SK.txt (for SK-CS16BTECH11032.cpp)
